import os
import maude
from maudeSE.converter.z3 import *
from maudeSE.connector.connector import *
from maudeSE.hook.check import *
from maudeSE.hook.search import *
from maudeSE.api import *

# initialize Maude interpreter

maude.init(advise=False)

# instantiate our interface

conv = Z3Converter()
conn = Z3Connector(conv)

# register special hooks

hook = CheckHook(conn, conv)
maude.connectEqHook('SmtCheckerSymbol', hook)

searchHook = SearchHook(conn, conv)
maude.connectEqHook('SmtSearchSymbol', searchHook)

# load preludes

maude.load('smt.maude')
maude.load(os.path.join(os.path.dirname(__file__), '.', 'maude-se.maude'))

# load example file

maude.load(os.path.join(os.path.dirname(__file__), '.', 'api-test.maude'))

gcd = maude.getModule('GCD')

init = gcd.parseTerm('gcd(10, I:Integer)')
goal = gcd.parseTerm('return(J:Integer)')

c = maude.EqualityCondition(gcd.parseTerm('I:Integer < 9 and I:Integer > 0'), 
							gcd.parseTerm('(true).Bool'))


gcd_result = smtSearch2(gcd, init, goal, c, "=>*", "unbounded", 7, False)
print(gcd_result)

print("==========================================")

robot = maude.getModule('ROBOT-DYNAMICS')


init = robot.parseTerm('< r : Robot | pos : [IPX:Real, IPY:Real], vel : [IVX:Real, IVY:Real], acc : [IAX:Real, IAY:Real], time : CLK:Real >')
goal = robot.parseTerm('< r : Robot | pos : [NPX:Real, NPY:Real], ATTRSET:AttributeSet >')

c = maude.EqualityCondition(robot.parseTerm("""NPX:Real === 10/1 and NPY:Real === 10/1 and IPX:Real === 0/1 and IPY:Real === 0/1 
					                            and IVX:Real === 0/1 and IVY:Real === 0/1 and IAX:Real === 0/1 
                                                and IAY:Real === 0/1 and CLK:Real === 0/1"""), 
							robot.parseTerm('(true).Bool'))


robot_result = smtSearch2(robot, init, goal, c, "=>*", "unbounded", 0, False)
print(robot_result)

print("==========================================")

robot_result = smtSearch2(robot, init, goal, c, "=>*", "unbounded", 0, True)
print(robot_result)
