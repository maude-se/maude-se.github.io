sudo apt install libpython3.8-dev
pip install importlib-resources z3-solver
pip install *.whl