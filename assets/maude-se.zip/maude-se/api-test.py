import os
import maudeSE.maude
from maudeSE.converter import *
from maudeSE.connector import *
from maudeSE.hook.check import *
from maudeSE.hook.search import *
from maudeSE.api import *

# initialize Maude interpreter

maudeSE.maude.init(advise=False)

# instantiate our interface

conv = Z3Converter()
conn = Z3Connector(conv)

# register special hooks

hook = CheckHook(conn, conv)
maudeSE.maude.connectEqHook('SmtCheckerSymbol', hook)

searchHook = SearchHook(conn, conv, path=False)
maudeSE.maude.connectEqHook('SmtSearchSymbol', searchHook)

# load preludes

maudeSE.maude.load('smt.maude')
maudeSE.maude.load('smt-check.maude')

# load example file

maudeSE.maude.load(os.path.join(os.path.dirname(__file__), '.', 'api-test.maude'))

gcd = maudeSE.maude.getModule('GCD')

init_s = gcd.parseTerm('gcd(10, I:Integer)')
goal_s = gcd.parseTerm('return(J:Integer)')

c = maudeSE.maude.EqualityCondition(gcd.parseTerm('I:Integer < 9 and I:Integer > 0'), 
							gcd.parseTerm('(true).Bool'))


gcd_result = smtSearch2(gcd, init_s, goal_s, c, "=>*", "unbounded", 8, "QF_LRA", False, False)
print(gcd_result)

print("==========================================")

robot = maudeSE.maude.getModule('ROBOT-DYNAMICS')


init_s = robot.parseTerm('< r : Robot | pos : [IPX:Real, IPY:Real], vel : [IVX:Real, IVY:Real], acc : [IAX:Real, IAY:Real], time : CLK:Real >')
goal_s = robot.parseTerm('< r : Robot | pos : [NPX:Real, NPY:Real], ATTRSET:AttributeSet >')

c = maudeSE.maude.EqualityCondition(robot.parseTerm("""NPX:Real === 10/1 and NPY:Real === 10/1 and IPX:Real === 0/1 and IPY:Real === 0/1 
					                            and IVX:Real === 0/1 and IVY:Real === 0/1 and IAX:Real === 0/1 
                                                and IAY:Real === 0/1 and CLK:Real === 0/1"""), 
							robot.parseTerm('(true).Bool'))


robot_result = smtSearch2(robot, init_s, goal_s, c, "=>*", "unbounded", 1, "QF_NRA", False, False)
print(robot_result)

print("==========================================")

robot_result = smtSearch2(robot, init_s, goal_s, c, "=>*", "unbounded", 1, "QF_NRA", True, False)
print(robot_result)
